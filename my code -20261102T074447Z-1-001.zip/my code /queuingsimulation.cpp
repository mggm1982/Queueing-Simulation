#include <iostream>                                      
#include <iomanip>
#include <vector>
using namespace std;

int main() {
    int n;

    cout << "==================================================\n";
    cout << "   QUEUEING SIMULATION AND PERFORMANCE ANALYSIS\n";
    cout << "==================================================\n";

    // STAGE 1: INPUT CUSTOMER DATA

    cout << "\nEnter number of customers: ";
    cin >> n;

    if (n <= 0) {
        cout << "Number of customers must be positive.\n";
        return 0;
    }

    vector<double> arrival(n);
    vector<double> service(n);

    cout << "\nEnter arrival and service times in minutes.\n";
    cout << "Arrival times must be in non-decreasing order.\n";

    for (int i = 0; i < n; i++) {
        cout << "\nCustomer " << i + 1 << "\n";

        cout << "Arrival time: ";
        cin >> arrival[i];

        cout << "Service duration: ";
        cin >> service[i];

        if (arrival[i] < 0 || service[i] <= 0) {
            cout << "Invalid input. Arrival must be non-negative "
                 << "and service duration must be positive.\n";
            return 0;
        }

        if (i > 0 && arrival[i] < arrival[i - 1]) {
            cout << "Arrival times must be in non-decreasing order.\n";
            return 0;
        }
    }

    cout << fixed << setprecision(2);

    // STAGE 2: SINGLE-SERVER SIMULATION

    vector<double> start1(n);
    vector<double> waiting1(n);
    vector<double> departure1(n);

    for (int i = 0; i < n; i++) {
        if (i == 0 || arrival[i] > departure1[i - 1]) {
            start1[i] = arrival[i];
        } else {
            start1[i] = departure1[i - 1];
        }

        waiting1[i] = start1[i] - arrival[i];
        departure1[i] = start1[i] + service[i];
    }

    cout << "\n==================================================\n";
    cout << "             STAGE 2: ONE SERVER\n";
    cout << "==================================================\n";

    cout << left
         << setw(10) << "Customer"
         << setw(10) << "Arrival"
         << setw(10) << "Service"
         << setw(10) << "Start"
         << setw(10) << "Waiting"
         << setw(10) << "Depart" << "\n";

    for (int i = 0; i < n; i++) {
        cout << left
             << setw(10) << i + 1
             << setw(10) << arrival[i]
             << setw(10) << service[i]
             << setw(10) << start1[i]
             << setw(10) << waiting1[i]
             << setw(10) << departure1[i] << "\n";
    }

    // STAGE 3: SINGLE-SERVER PERFORMANCE ANALYSIS

    double totalWaiting1 = 0;
    double totalSystemTime1 = 0;
    double totalService = 0;

    for (int i = 0; i < n; i++) {
        totalWaiting1 += waiting1[i];
        totalSystemTime1 += departure1[i] - arrival[i];
        totalService += service[i];
    }

    double duration1 = departure1[n - 1] - arrival[0];

    double averageWaiting1 = totalWaiting1 / n;
    double averageSystemTime1 = totalSystemTime1 / n;
    double utilization1 = (totalService / duration1) * 100.0;
    double throughput1 = n / duration1;

    cout << "\n==================================================\n";
    cout << "        STAGE 3: ONE-SERVER PERFORMANCE\n";
    cout << "==================================================\n";

    cout << "Customers served: " << n << "\n";
    cout << "Average waiting time: "
         << averageWaiting1 << " minutes\n";
    cout << "Average time in system: "
         << averageSystemTime1 << " minutes\n";
    cout << "Total service time: "
         << totalService << " minutes\n";
    cout << "Simulation duration: "
         << duration1 << " minutes\n";
    cout << "Server utilization: "
         << utilization1 << "%\n";
    cout << "Throughput: "
         << throughput1 << " customers per minute\n";

    // STAGE 4: TWO-SERVER SIMULATION

    vector<double> start2(n);
    vector<double> waiting2(n);
    vector<double> departure2(n);
    vector<int> assignedServer(n);

    double available1 = 0;
    double available2 = 0;

    for (int i = 0; i < n; i++) {
        int chosenServer;

        // Choose the server that becomes available first.
        if (available1 <= available2) {
            chosenServer = 1;
        } else {
            chosenServer = 2;
        }

        assignedServer[i] = chosenServer;

        double availableTime;

        if (chosenServer == 1) {
            availableTime = available1;
        } else {
            availableTime = available2;
        }

        if (arrival[i] > availableTime) {
            start2[i] = arrival[i];
        } else {
            start2[i] = availableTime;
        }

        waiting2[i] = start2[i] - arrival[i];
        departure2[i] = start2[i] + service[i];

        if (chosenServer == 1) {
            available1 = departure2[i];
        } else {
            available2 = departure2[i];
        }
    }

    cout << "\n==================================================\n";
    cout << "             STAGE 4: TWO SERVERS\n";
    cout << "==================================================\n";

    cout << left
         << setw(10) << "Customer"
         << setw(10) << "Arrival"
         << setw(10) << "Service"
         << setw(10) << "Server"
         << setw(10) << "Start"
         << setw(10) << "Waiting"
         << setw(10) << "Depart" << "\n";

    for (int i = 0; i < n; i++) {
        cout << left
             << setw(10) << i + 1
             << setw(10) << arrival[i]
             << setw(10) << service[i]
             << setw(10) << assignedServer[i]
             << setw(10) << start2[i]
             << setw(10) << waiting2[i]
             << setw(10) << departure2[i] << "\n";
    }

    // TWO-SERVER PERFORMANCE ANALYSIS

    double totalWaiting2 = 0;
    double totalSystemTime2 = 0;
    double totalBusyTime2 = 0;
    double lastDeparture2 = departure2[0];

    for (int i = 0; i < n; i++) {
        totalWaiting2 += waiting2[i];
        totalSystemTime2 += departure2[i] - arrival[i];
        totalBusyTime2 += service[i];

        if (departure2[i] > lastDeparture2) {
            lastDeparture2 = departure2[i];
        }
    }

    double duration2 = lastDeparture2 - arrival[0];

    double averageWaiting2 = totalWaiting2 / n;
    double averageSystemTime2 = totalSystemTime2 / n;
    double utilization2 =
        (totalBusyTime2 / (2.0 * duration2)) * 100.0;
    double throughput2 = n / duration2;

    cout << "\n==================================================\n";
    cout << "        TWO-SERVER PERFORMANCE\n";
    cout << "==================================================\n";

    cout << "Customers served: " << n << "\n";
    cout << "Average waiting time: "
         << averageWaiting2 << " minutes\n";
    cout << "Average time in system: "
         << averageSystemTime2 << " minutes\n";
    cout << "Total service time: "
         << totalBusyTime2 << " minutes\n";
    cout << "Simulation duration: "
         << duration2 << " minutes\n";
    cout << "Combined server utilization: "
         << utilization2 << "%\n";
    cout << "Throughput: "
         << throughput2 << " customers per minute\n";

    // STAGE 5: COMPARISON REPORT

    cout << "\n==================================================\n";
    cout << "          STAGE 5: COMPARISON REPORT\n";
    cout << "==================================================\n";

    cout << left
         << setw(28) << "Performance metric"
         << setw(16) << "One server"
         << setw(16) << "Two servers" << "\n";

    cout << "--------------------------------------------------\n";

    cout << left
         << setw(28) << "Average waiting (min)"
         << setw(16) << averageWaiting1
         << setw(16) << averageWaiting2 << "\n";

    cout << left
         << setw(28) << "Average system time (min)"
         << setw(16) << averageSystemTime1
         << setw(16) << averageSystemTime2 << "\n";

    cout << left
         << setw(28) << "Throughput (customers/min)"
         << setw(16) << throughput1
         << setw(16) << throughput2 << "\n";

    cout << left
         << setw(28) << "Server utilization (%)"
         << setw(16) << utilization1
         << setw(16) << utilization2 << "\n";

    cout << "\nWaiting-time reduction: ";

    if (averageWaiting1 > 0) {
        double reduction =
            ((averageWaiting1 - averageWaiting2)
             / averageWaiting1) * 100.0;

        cout << reduction << "%\n";
    } else {
        cout << "Not applicable (one-server waiting time is zero).\n";
    }

    cout << "\nFINAL OBSERVATION\n";

    if (averageWaiting2 < averageWaiting1) {
        cout << "Two servers reduced average waiting time.\n";
    } else if (averageWaiting2 == averageWaiting1) {
        cout << "Both systems have equal average waiting time.\n";
    } else {
        cout << "Two servers have higher average waiting time. "
             << "Check the simulation.\n";
    }

    if (averageSystemTime2 < averageSystemTime1) {
        cout << "Two servers reduced average time in the system.\n";
    } else if (averageSystemTime2 == averageSystemTime1) {
        cout << "Average time in the system is equal.\n";
    } else {
        cout << "Average time in the system increased.\n";
    }

    // STAGE 6: AUTOMATIC M/M/1 THEORETICAL ANALYSIS

    cout << "\n==================================================\n";
    cout << "           STAGE 6: M/M/1 ANALYSIS\n";
    cout << "==================================================\n";

    // Calculate average service time from entered data.
    double averageServiceTime = totalService / n;

    cout << "Average service time: "
         << averageServiceTime << " minutes\n";

    // At least two arrivals are needed to estimate
    // the average inter-arrival time.
    if (n < 2) {
        cout << "At least two customers are required to "
             << "calculate average inter-arrival time.\n";
    } else {
        double totalInterArrival = 0;

        for (int i = 1; i < n; i++) {
            totalInterArrival += arrival[i] - arrival[i - 1];
        }

        double averageInterArrival =
            totalInterArrival / (n - 1);

        cout << "Average inter-arrival time: "
             << averageInterArrival << " minutes\n";

        if (averageInterArrival <= 0) {
            cout << "Average inter-arrival time is zero.\n";
            cout << "A finite arrival rate cannot be calculated.\n";
        } else {
            // Arrival and service rates.
            double lambda = 1.0 / averageInterArrival;
            double mu = 1.0 / averageServiceTime;

            cout << "Arrival rate (lambda): "
                 << lambda << " customers per minute\n";

            cout << "Service rate (mu): "
                 << mu << " customers per minute\n";

            // M/M/1 steady-state formulas apply only if lambda < mu.
            if (lambda < mu) {
                double rho = lambda / mu;
                double Wq = lambda / (mu * (mu - lambda));
                double W = 1.0 / (mu - lambda);
                double Lq = lambda * Wq;
                double L = lambda * W;

                cout << "\nTHEORETICAL M/M/1 RESULTS\n";
                cout << "-------------------------\n";

                cout << "Utilization: "
                     << rho * 100.0 << "%\n";

                cout << "Average waiting time (Wq): "
                     << Wq << " minutes\n";

                cout << "Average time in system (W): "
                     << W << " minutes\n";

                cout << "Average queue length (Lq): "
                     << Lq << " customers\n";

                cout << "Average customers in system (L): "
                     << L << " customers\n";

                cout << "\nSIMULATION AND THEORY COMPARISON\n";
                cout << "--------------------------------\n";

                cout << "Simulated average waiting time: "
                     << averageWaiting1 << " minutes\n";

                cout << "Theoretical average waiting time: "
                     << Wq << " minutes\n" ; 

                cout << "Simulated average time in system: "
                     << averageSystemTime1 << " minutes\n";

                cout << "Theoretical average time in system: "
                     << W << " minutes\n";

                cout << "\nNote: M/M/1 assumes random arrivals "
                     << "and exponentially distributed service times.\n";

                cout << "Theoretical results may differ from "
                     << "the manually entered simulation data.\n";
            } else {
                cout << "\nThe M/M/1 model is unstable because "
                     << "lambda >= mu.\n";

                cout << "Steady-state averages cannot be calculated "
                     << "using these formulas.\n";
            }
        }
    }

    cout << "\n==================================================\n";
    cout << "       SIMULATION COMPLETED SUCCESSFULLY\n";
    cout << "==================================================\n";

    return 0;
}         